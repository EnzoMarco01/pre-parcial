package api;

public interface PilaColaParesTDA {

    void inicializar();

    void guardar(int x);

    void sacar();

    int mostrar();

    boolean vacia();

    void imprimir();

}
