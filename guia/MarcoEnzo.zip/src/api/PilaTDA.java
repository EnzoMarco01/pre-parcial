package api;

public interface PilaTDA {

    void inicializarPila();

    void apilar(int x);

    void desapilar();

    int tope();

    boolean pilaVacia();
    
}