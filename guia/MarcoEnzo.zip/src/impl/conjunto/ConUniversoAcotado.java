package impl.conjunto;

import api.ConjuntoTDA;

public class ConUniversoAcotado implements ConjuntoTDA{

  public void inicializarConjunto() {
    throw new UnsupportedOperationException("Unimplemented method 'inicializarConjunto'");
  }

  public boolean conjuntoVacio() {
    throw new UnsupportedOperationException("Unimplemented method 'conjuntoVacio'");
  }

  public void agregar(int x) {
    throw new UnsupportedOperationException("Unimplemented method 'agregar'");
  }

  public int elegir() {
    throw new UnsupportedOperationException("Unimplemented method 'elegir'");
  }

  public void sacar(int x) {
    throw new UnsupportedOperationException("Unimplemented method 'sacar'");
  }

  public boolean pertenece(int x) {
    throw new UnsupportedOperationException("Unimplemented method 'pertenece'");
  }

}
