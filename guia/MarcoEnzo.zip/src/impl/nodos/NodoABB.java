package impl.nodos;

import api.ABBTDA;

public class NodoABB {
    public int info;
    public ABBTDA hijoIzq;
    public ABBTDA hijoDer;
}
