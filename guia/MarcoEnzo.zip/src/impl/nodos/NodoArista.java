package impl.nodos;

public class NodoArista {
  public int etiqueta;
  public NodoGrafo nodoDestino;
  public NodoArista sigArista;
}
