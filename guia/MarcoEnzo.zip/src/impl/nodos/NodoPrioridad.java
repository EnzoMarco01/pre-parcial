package impl.nodos;

public class NodoPrioridad {
    public int info;
    public int prioridad;
    public NodoPrioridad sig;
}