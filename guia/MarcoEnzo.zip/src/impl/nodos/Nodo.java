package impl.nodos;

public class Nodo {
    public int info;
    public Nodo sig;
}