package impl.nodos;

public class NodoGrafo {
  public int nodo;
  public NodoArista arista;
  public NodoGrafo sigNodo;
}
